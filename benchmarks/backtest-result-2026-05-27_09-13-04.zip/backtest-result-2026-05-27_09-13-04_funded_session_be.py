import sys
from pathlib import Path
from datetime import datetime
from pandas import DataFrame

sys.path.append(str(Path(__file__).parent.parent.parent))

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType
)

from core.indicators import fvg, pp, bos
from core.entry import fib
from core.annotations import tp_sl, tp_sl_dev

class funded_session_be(IStrategy):
    can_short = True

    minimal_roi = {
        "0": 100
    }

    # Wide fallback — custom_stoploss uses fib level 0 as structural SL,
    # then switches to trailing once the offset is reached
    stoploss = -0.03

    trailing_stop = False
    trailing_offset: float = 0.03   # start trailing after +3% profit
    trailing_distance: float = 0.02  # trail 2% below high-water mark

    use_custom_stoploss = True

    process_only_new_candles = True
    use_exit_signal = True  # required for custom_exit() to be called

    startup_candle_count: int = 10

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True
    }

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float | None:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return None

        before_open = dataframe[dataframe['date'] < trade.open_date_utc]
        if before_open.empty:
            return None

        sl_col = 'fib_range_low' if not trade.is_short else 'fib_range_high'
        conf = before_open[before_open[sl_col].notna()]
        if conf.empty:
            return None

        sl_price = float(conf.iloc[-1][sl_col])
        fib_sl = stoploss_from_absolute(sl_price, current_rate, is_short=trade.is_short, leverage=trade.leverage)

        # Phase 1: structural fib SL — can only fire as a loss
        # Phase 2: pure trailing — ratcheting maintains high-water mark, can only fire as a win
        if current_profit >= self.trailing_offset:
            return -self.trailing_distance

        return fib_sl

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime,
                    current_rate: float, current_profit: float, **kwargs):
        if (current_time - trade.open_date_utc).total_seconds() / 3600 > 24:
            return 'timeout'
        return None

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe[['fvg_bull', 'fvg_bear', 'fvg_bull_size', 'fvg_bear_size']] = fvg.fvg(dataframe)
        dataframe[['pivot_label_high', 'pivot_label_low']] = pp.pp(dataframe)
        dataframe[['bos_bull', 'bos_bear', 'bos_level', 'bos_level_abs']] = bos.bos(dataframe, dataframe['pivot_label_high'], dataframe['pivot_label_low'])
        fib.fib(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # London 07:00-17:00 UTC + NY 12:00-22:00 UTC → combined active window 07:00-22:00, weekdays only
        hour = dataframe['date'].dt.hour
        weekday = dataframe['date'].dt.dayofweek  # 0=Mon, 4=Fri, 5=Sat, 6=Sun
        in_session = (hour >= 7) & (hour < 22) & (weekday < 5)

        dataframe["enter_long"] = (dataframe['fib_bull_confirmation'] & in_session).astype(bool).astype(int)
        dataframe["enter_short"] = (dataframe['fib_bear_confirmation'] & in_session).astype(bool).astype(int)

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def plot_annotations(self, pair: str, start_date: datetime, end_date: datetime, dataframe: DataFrame, **kwargs,) -> list[AnnotationType]:
        annotations: list[AnnotationType] = []

        annotations.extend(fvg.fvg_annotations(dataframe, start_date, end_date))
        annotations.extend(pp.pp_annotations(dataframe, start_date, end_date))
        annotations.extend(bos.bos_annotations(dataframe, start_date, end_date))
        annotations.extend(fib.fib_annotations(dataframe, start_date, end_date))

        tp_sl_switch = tp_sl if (Trade.use_db and hasattr(Trade, "session")) else tp_sl_dev
        annotations.extend(
            tp_sl_switch.tp_sl_annotations(
                pair,
                dataframe,
                start_date,
                end_date,
                self.stoploss,
                0,
                0,
                num_trades=100,
                **kwargs,
            )
        )

        return annotations
