import sys
from pathlib import Path
from datetime import datetime
from pandas import DataFrame

sys.path.append(str(Path(__file__).parent.parent.parent))

from freqtrade.strategy import (
    IStrategy,
    Trade,
    stoploss_from_absolute,
)


class orb(IStrategy):
    """
    Opening Range Breakout (ORB).

    Defines the opening range as the high/low of the first `orb_candles` 15m candles
    after 00:00 UTC each day, then enters on a close breakout above/below that range.
    Stop is placed at the opposite edge of the range.
    """

    can_short = True

    # Number of 15m candles that define the opening range (2 = 30 min, 4 = 1h)
    orb_candles: int = 2

    # Don't enter new trades after this UTC hour
    session_end_hour: int = 22

    minimal_roi = {"0": 100}

    # Fallback stoploss if ORB range is unavailable
    stoploss = -0.05

    trailing_stop = True
    trailing_stop_positive = 0.020
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_custom_stoploss = True

    process_only_new_candles = True
    use_exit_signal = False

    startup_candle_count: int = 100

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True,
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['_orb_day'] = dataframe['date'].dt.floor('D')
        dataframe['_candle_of_day'] = dataframe.groupby('_orb_day').cumcount()

        def _day_orb(group):
            window = group[group['_candle_of_day'] < self.orb_candles]
            group['orb_high'] = window['high'].max() if len(window) > 0 else float('nan')
            group['orb_low'] = window['low'].min() if len(window) > 0 else float('nan')
            return group

        dataframe = dataframe.groupby('_orb_day', group_keys=False).apply(_day_orb)

        # Ready only once all opening-range candles have closed
        dataframe['orb_ready'] = dataframe['_candle_of_day'] >= self.orb_candles

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        hour = dataframe['date'].dt.hour
        in_window = dataframe['orb_ready'] & (hour < self.session_end_hour)

        dataframe['enter_long'] = (
            in_window & (dataframe['close'] > dataframe['orb_high'])
        ).astype(int)

        dataframe['enter_short'] = (
            in_window & (dataframe['close'] < dataframe['orb_low'])
        ).astype(int)

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def custom_stoploss(
        self,
        pair: str,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        after_fill: bool,
        **kwargs,
    ) -> float | None:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return None

        entry_candles = dataframe[dataframe['date'] <= trade.open_date_utc]
        if entry_candles.empty:
            return None

        entry_candle = entry_candles.iloc[-1]
        stop_price = entry_candle['orb_low'] if not trade.is_short else entry_candle['orb_high']

        return stoploss_from_absolute(
            stop_price,
            current_rate,
            is_short=trade.is_short,
            leverage=trade.leverage,
        )
