import sys
from pathlib import Path
from datetime import datetime
import pandas as pd
from pandas import DataFrame

sys.path.append(str(Path(__file__).parent.parent.parent))

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType
)

from core.indicators import fvg, pp, bos
from core.entry import fib
from core.annotations import tp_sl, tp_sl_dev


class funded_fib_levels(IStrategy):
    can_short = True

    minimal_roi = {
        "0": 100
    }

    # Wide fallback — real SL/TP managed entirely by custom_stoploss.
    stoploss = -0.5

    trailing_stop = False

    use_custom_stoploss = True
    be_lookback_hours: int = 35
    risk_per_trade: float = 0.02

    process_only_new_candles = True
    use_exit_signal = False

    startup_candle_count: int = 10

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True
    }

    @property
    def protections(self):
        return [
            {
                "method": "MaxDrawdown",
                "calculation_mode": "equity",
                "lookback_period": 1440,
                "trade_limit": 2,
                "max_allowed_drawdown": 0.035,
                "stop_duration": 1440,
            },
        ]

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: float | None, max_stake: float,
                            leverage: float, entry_tag: str | None, side: str,
                            **kwargs) -> float:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair=pair, timeframe=self.timeframe)
        if dataframe.empty:
            return proposed_stake

        is_short = side == 'short'
        signal_col = 'fib_bear_confirmation' if is_short else 'fib_bull_confirmation'
        signal_candles = dataframe[
            (dataframe['date'] < current_time) &
            (dataframe[signal_col] == True) &
            (dataframe['fib_sl_price'].notna())
        ]
        if signal_candles.empty:
            return proposed_stake

        sl_price = float(signal_candles.iloc[-1]['fib_sl_price'])
        sl_distance = abs(current_rate - sl_price) / current_rate
        if sl_distance < 0.001:
            return proposed_stake

        # stake * leverage * sl_distance = account * risk_per_trade
        # → stake = (account * risk) / (leverage * sl_distance)
        # loss if SL hits = account * risk_per_trade, regardless of leverage
        total_balance = self.wallets.get_total_stake_amount()
        stake = (total_balance * self.risk_per_trade) / (sl_distance * leverage)
        return float(min(max_stake, max(min_stake or 0.0, stake)))

    def _get_fib_levels(self, trade: Trade, dataframe: DataFrame):
        """Return (tp_price, sl_price) from the signal candle that opened this trade."""
        signal_col = 'fib_bear_confirmation' if trade.is_short else 'fib_bull_confirmation'
        signal_candles = dataframe[
            (dataframe['date'] < trade.open_date_utc) &
            (dataframe[signal_col] == True) &
            (dataframe['fib_tp_price'].notna())
        ]
        if signal_candles.empty:
            return None, None
        last = signal_candles.iloc[-1]
        return float(last['fib_tp_price']), float(last['fib_sl_price'])

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float | None:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        tp, sl = self._get_fib_levels(trade, dataframe)
        if tp is None or sl is None:
            return None

        # TP reached: set a near-zero stop so the trade closes immediately at this candle.
        # custom_stoploss is evaluated intrabar, so this fires at the TP price level.
        if not trade.is_short and current_rate >= tp:
            return -0.0001
        if trade.is_short and current_rate <= tp:
            return -0.0001

        # Break even: after lookback window, if in profit lock SL at entry price.
        trade_duration_hours = (current_time - trade.open_date_utc).total_seconds() / 3600
        if trade_duration_hours >= self.be_lookback_hours and current_profit > 0:
            return stoploss_from_open(0.0, current_profit, is_short=trade.is_short, leverage=trade.leverage) or 1

        # Normal SL: hold at the fib range boundary
        return stoploss_from_absolute(sl, current_rate, is_short=trade.is_short, leverage=trade.leverage)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe[['fvg_bull', 'fvg_bear', 'fvg_bull_size', 'fvg_bear_size']] = fvg.fvg(dataframe)
        dataframe[['pivot_label_high', 'pivot_label_low']] = pp.pp(dataframe)
        dataframe[['bos_bull', 'bos_bear', 'bos_level', 'bos_level_abs']] = bos.bos(dataframe, dataframe['pivot_label_high'], dataframe['pivot_label_low'])
        fib.fib(dataframe)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = dataframe['fib_bull_confirmation'].astype(bool).astype(int)
        dataframe["enter_short"] = dataframe['fib_bear_confirmation'].astype(bool).astype(int)
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def plot_annotations(self, pair: str, start_date: datetime, end_date: datetime, dataframe: DataFrame, **kwargs) -> list[AnnotationType]:
        annotations: list[AnnotationType] = []
        annotations.extend(fvg.fvg_annotations(dataframe, start_date, end_date))
        annotations.extend(pp.pp_annotations(dataframe, start_date, end_date))
        annotations.extend(bos.bos_annotations(dataframe, start_date, end_date))
        annotations.extend(fib.fib_annotations(dataframe, start_date, end_date, num_zones=100))
        tp_sl_switch = tp_sl if (Trade.use_db and hasattr(Trade, "session")) else tp_sl_dev
        annotations.extend(
            tp_sl_switch.tp_sl_annotations(
                pair, dataframe, start_date, end_date,
                self.stoploss,
                0,
                0,
                num_trades=100,
                **kwargs,
            )
        )
        return annotations