import sys
from pathlib import Path
from datetime import datetime
from pandas import DataFrame

# Add workspace root to path to import functions module
sys.path.append(str(Path(__file__).parent.parent.parent))

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,  # @informative decorator
    # timeframe helpers
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    # Strategy helper functions
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType
)

from core.indicators import fvg, pp, bos
from core.entry import fib
from core.annotations import tp_sl, tp_sl_dev

class funded_be(IStrategy):
    can_short = True

    minimal_roi = {
        "0": 100
    }

    stoploss = -0.02

    trailing_stop = True
    trailing_stop_positive = 0.020
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_custom_stoploss = True
    be_lookback_hours: int = 35

    process_only_new_candles = True
    use_exit_signal = False

    startup_candle_count: int = 10

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True
    }

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float | None:
        trade_duration_hours = (current_time - trade.open_date_utc).total_seconds() / 3600
        if trade_duration_hours >= self.be_lookback_hours and current_profit > 0:
            return stoploss_from_open(0.0, current_profit, is_short=trade.is_short, leverage=trade.leverage) or 1
        return None

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe[['fvg_bull', 'fvg_bear', 'fvg_bull_size', 'fvg_bear_size']] = fvg.fvg(dataframe)
        dataframe[['pivot_label_high', 'pivot_label_low']] = pp.pp(dataframe)
        dataframe[['bos_bull', 'bos_bear', 'bos_level', 'bos_level_abs']] = bos.bos(dataframe, dataframe['pivot_label_high'], dataframe['pivot_label_low'])
        fib.fib(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        trend_up = (
            (dataframe['fib_bull_confirmation'])
        )

        trend_down = (
            (dataframe['fib_bear_confirmation'])
        )

        dataframe["enter_long"] = trend_up.astype(bool).astype(int)
        dataframe["enter_short"] = trend_down.astype(bool).astype(int)

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def plot_annotations(self, pair: str, start_date: datetime, end_date: datetime, dataframe: DataFrame, **kwargs,) -> list[AnnotationType]:
        annotations: list[AnnotationType] = []

        annotations.extend(fvg.fvg_annotations(dataframe, start_date, end_date))
        annotations.extend(pp.pp_annotations(dataframe, start_date, end_date))
        annotations.extend(bos.bos_annotations(dataframe, start_date, end_date))
        annotations.extend(fib.fib_annotations(dataframe, start_date, end_date))

        tp_sl_switch = tp_sl if (Trade.use_db and hasattr(Trade, "session")) else tp_sl_dev
        annotations.extend(
            tp_sl_switch.tp_sl_annotations(
                pair,
                dataframe,
                start_date,
                end_date,
                self.stoploss,
                self.trailing_stop_positive,
                self.trailing_stop_positive_offset,
                num_trades=100,
                **kwargs,
            )
        )

        return annotations
