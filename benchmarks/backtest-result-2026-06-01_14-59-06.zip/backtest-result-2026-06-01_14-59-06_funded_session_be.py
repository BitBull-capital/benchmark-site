import sys
from pathlib import Path
from datetime import datetime
from pandas import DataFrame

sys.path.append(str(Path(__file__).parent.parent.parent))

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType
)

from core.indicators import fvg, pp, bos
from core.entry import fib
from core.annotations import tp_sl, tp_sl_dev

class funded_session_be(IStrategy):
    can_short = True

    minimal_roi = {
        "0": 100
    }

    stoploss = -0.01

    trailing_stop = True
    trailing_stop_positive = 0.003          # lock 0.3% once offset hit
    trailing_stop_positive_offset = 0.005   # start trailing after 0.5%
    trailing_only_offset_is_reached = True

    use_custom_stoploss = True
    be_lookback_hours: float = 3.0          # move to BE after 3h if no trailing yet

    process_only_new_candles = True
    use_exit_signal = False

    startup_candle_count: int = 10

    order_types = {
        "entry": "market",
        "exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True
    }

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float | None:
        trade_duration_hours = (current_time - trade.open_date_utc).total_seconds() / 3600
        if trade_duration_hours >= self.be_lookback_hours and current_profit > 0:
            return stoploss_from_open(0.0, current_profit, is_short=trade.is_short, leverage=trade.leverage) or 1
        return None

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe[['fvg_bull', 'fvg_bear', 'fvg_bull_size', 'fvg_bear_size']] = fvg.fvg(dataframe)
        dataframe[['pivot_label_high', 'pivot_label_low']] = pp.pp(dataframe)
        dataframe[['bos_bull', 'bos_bear', 'bos_level', 'bos_level_abs']] = bos.bos(dataframe, dataframe['pivot_label_high'], dataframe['pivot_label_low'])
        fib.fib(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # London 07:00-17:00 UTC + NY 12:00-22:00 UTC → combined active window 07:00-22:00, weekdays only
        hour = dataframe['date'].dt.hour
        weekday = dataframe['date'].dt.dayofweek  # 0=Mon, 4=Fri, 5=Sat, 6=Sun
        in_session = (hour >= 7) & (hour < 22) & (weekday < 5)

        dataframe["enter_long"] = (dataframe['fib_bull_confirmation'] & in_session).astype(bool).astype(int)
        dataframe["enter_short"] = (dataframe['fib_bear_confirmation'] & in_session).astype(bool).astype(int)

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def plot_annotations(self, pair: str, start_date: datetime, end_date: datetime, dataframe: DataFrame, **kwargs,) -> list[AnnotationType]:
        annotations: list[AnnotationType] = []

        annotations.extend(fvg.fvg_annotations(dataframe, start_date, end_date))
        annotations.extend(pp.pp_annotations(dataframe, start_date, end_date))
        annotations.extend(bos.bos_annotations(dataframe, start_date, end_date))
        annotations.extend(fib.fib_annotations(dataframe, start_date, end_date))

        tp_sl_switch = tp_sl if (Trade.use_db and hasattr(Trade, "session")) else tp_sl_dev
        annotations.extend(
            tp_sl_switch.tp_sl_annotations(
                pair,
                dataframe,
                start_date,
                end_date,
                self.stoploss,
                self.trailing_stop_positive,
                self.trailing_stop_positive_offset,
                num_trades=100,
                **kwargs,
            )
        )

        return annotations
