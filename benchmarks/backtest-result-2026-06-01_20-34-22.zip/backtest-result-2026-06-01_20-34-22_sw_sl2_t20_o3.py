import sys
from pathlib import Path
from pandas import DataFrame
sys.path.append(str(Path(__file__).parent.parent.parent))
from freqtrade.strategy import IStrategy, Trade, AnnotationType
from core.indicators import fvg, pp, bos
from core.entry import fib

class sw_sl2_t20_o3(IStrategy):
    """sl=-0.02 trail=0.02 offset=0.03"""
    can_short = True
    minimal_roi = {"0": 100}
    stoploss = -0.02
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True
    process_only_new_candles = True
    use_exit_signal = False
    startup_candle_count: int = 10
    order_types = {"entry": "market", "exit": "market", "stoploss": "market", "stoploss_on_exchange": True}

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe[["fvg_bull", "fvg_bear", "fvg_bull_size", "fvg_bear_size"]] = fvg.fvg(dataframe)
        dataframe[["pivot_label_high", "pivot_label_low"]] = pp.pp(dataframe)
        dataframe[["bos_bull", "bos_bear", "bos_level", "bos_level_abs"]] = bos.bos(dataframe, dataframe["pivot_label_high"], dataframe["pivot_label_low"])
        fib.fib(dataframe)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = (dataframe["fib_bull_confirmation"]).astype(bool).astype(int)
        dataframe["enter_short"] = (dataframe["fib_bear_confirmation"]).astype(bool).astype(int)
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe
